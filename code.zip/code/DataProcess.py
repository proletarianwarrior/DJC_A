# -*- coding: utf-8 -*-
# @Time : 2023/10/12 23:08
# @Author : DanYang
# @File : DataProcess.py
# @Software : PyCharm
import sys

sys.path.append("../config")

import pathlib
from plotly.subplots import make_subplots
import pandas as pd

from config import *
from my_log import logger


def load_file(file_path: pathlib.Path):
    """
    读取csv文件中的数据(编码格式为-简体中文GB2312)，无法编码的字符使用反斜线转义。
    :param file_path: csv文件路径
    :return: 读取后的数据
    """
    try:
        df = pd.read_csv(file_path, encoding="GB2312", encoding_errors="backslashreplace")
        logger.info(f"读取文件{file_path}成功!")
        return df
    except Exception as e:
        logger.error(e.args[0])
        raise e


def concat_file():
    """
    将两组数据进行合并
    :return: 合并后的数据
    """
    sen_df = load_file(SEN_FILE_PATH)
    insen_df = load_file(INSEN_FILE_PATH)

    concat_df = pd.concat((insen_df, sen_df), axis="index", ignore_index=True)
    logger.info("合并数据成功！")

    return concat_df


def save_concat_data():
    """
    将合并后的数据保存为训练集数据
    :return: None
    """
    concat_df = concat_file()
    concat_df.to_csv("../data/train.csv")
    logger.info("数据保存成功！")


def analyse_data_plot():
    """
    绘制统计图分析所有文本内容的词长； 分析违规信息和违规信息数量的占比。
    :return:
    """
    df = concat_file()
    fig = make_subplots(
        rows=2,
        cols=2,
        column_widths=[0.6, 0.4],
        row_heights=[0.5, 0.5],
        specs=[[{"type": "box", "rowspan": 2}, {"type": "bar"}],
               [None, {"type": "pie"}]]
    )

    x_bar = ["违规", "非违规"]
    y_bar = [df[df["label"] == 1].shape[0], df[df["label"] == 0].shape[0]]
    fig.add_bar(x=x_bar, y=y_bar, marker_color=["#72DCC6", "#C7A7F8"],
                showlegend=False, row=1, col=2)

    labels_pie = x_bar.copy()
    values_pie = y_bar.copy()
    fig.add_pie(labels=labels_pie, values=values_pie, marker={"colors": ["#72DCC6", "#C7A7F8"]},
                hole=0.4, showlegend=False, row=2, col=2)

    s_y_box = df[df["label"] == 1]["0"].apply(len)
    ins_y_box = df[df["label"] == 0]["0"].apply(len)

    fig.add_box(y=s_y_box, name="违规", row=1, col=1)
    fig.add_box(y=ins_y_box, name="非违规", row=1, col=1)

    fig.update_layout(
        yaxis1_title="词长",
        yaxis2_title="信息数量"
    )

    fig.show()


if __name__ == '__main__':
    analyse_data_plot()

