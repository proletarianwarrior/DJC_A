# -*- coding: utf-8 -*-
# @Time : 2023/11/6 17:08
# @Author : DanYang
# @File : bert_model.py
# @Software : PyCharm
import numpy as np
import pandas as pd
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, TensorDataset
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score

from DataProcess import load_file
from word_cloud import del_stopwords, cut_sentences
from my_log import logger

df = pd.read_csv("../data/train_words.csv")
X = df["cut_words"].astype(str)
y = df["label"]

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

X_train = X_train.to_numpy()
X_val = X_val.to_numpy()
y_train = y_train.to_numpy()
y_val = y_val.to_numpy()

model_name = '../model/bert-base-chinese'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertForSequenceClassification.from_pretrained(model_name, num_labels=2)


def tokenize_text(text):
    inputs = tokenizer(text, padding='max_length', max_length=128, truncation=True, return_tensors='pt')
    return inputs


def train_model(num_epochs=5):
    input_ids = []
    attention_mask = []
    for text in X_train:
        inputs = tokenize_text(text)
        input_ids.append(inputs["input_ids"])
        attention_mask.append(inputs["attention_mask"])

    input_ids = torch.cat(input_ids, dim=0)
    attention_mask = torch.cat(attention_mask, dim=0)
    labels = torch.tensor(y_train)

    dataset = TensorDataset(input_ids, attention_mask, labels)
    batch_size = 32
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=1e-5)

    for epoch in range(num_epochs):
        model.train()
        total_loss = 0

        for batch in dataloader:
            input_ids, attention_mask, labels = batch
            optimizer.zero_grad()
            outputs = model(input_ids, attention_mask=attention_mask)
            logits = outputs.logits
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        average_loss = total_loss / len(dataloader)
        print(f'Epoch {epoch + 1}/{num_epochs}, Loss: {average_loss:.4f}')

    model.save_pretrained('../model/bert_model')


def test_model():
    model = BertForSequenceClassification.from_pretrained('../model/bert_model')

    input_ids = []
    attention_mask = []
    for text in X_val:
        inputs = tokenize_text(text)
        input_ids.append(inputs["input_ids"])
        attention_mask.append(inputs["attention_mask"])

    input_ids = torch.cat(input_ids, dim=0)
    attention_mask = torch.cat(attention_mask, dim=0)
    labels = torch.tensor(y_val)

    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    logits = outputs["logits"]
    probabilities = F.softmax(logits, dim=1)
    predicted_labels = torch.argmax(probabilities, dim=1)

    predicted_labels = np.array(predicted_labels)
    labels = np.array(labels)

    test_df = pd.DataFrame(data=np.vstack((labels, predicted_labels)).T, columns=["predict_y_val", "y_val"])
    test_df.to_csv("../output/test.csv")


def predict_output():
    df = load_file("../data/test.csv")
    texts = df["0"]
    texts = np.array([" ".join(del_stopwords(cut_sentences(t))) for t in texts], dtype=str)
    model = BertForSequenceClassification.from_pretrained('../model/bert_model')

    input_ids = []
    attention_mask = []
    for text in texts:
        inputs = tokenize_text(text)
        input_ids.append(inputs["input_ids"])
        attention_mask.append(inputs["attention_mask"])

    input_ids = torch.cat(input_ids, dim=0)
    attention_mask = torch.cat(attention_mask, dim=0)

    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    logits = outputs["logits"]
    probabilities = F.softmax(logits, dim=1)
    predicted_labels = torch.argmax(probabilities, dim=1)

    predicted_labels = np.array(predicted_labels)

    df["label"] = predicted_labels
    df.to_csv("../output/output.csv")


def get_model_score():
    s_df = pd.read_csv("../output/test.csv")
    p_y_val = s_df["predict_y_val"]
    y_val = s_df["y_val"]

    p = precision_score(y_val, p_y_val)
    r = recall_score(y_val, p_y_val)
    f1 = f1_score(y_val, p_y_val)
    a = accuracy_score(y_val, p_y_val)

    print(f"precision score: {p: .4f}\nrecall score: {r: .4f}\nf1 score: {f1: .4f}\naccuracy score: {a: .4f}")


if __name__ == '__main__':
    get_model_score()
