# -*- coding: utf-8 -*-
# @Time : 2023/10/12 23:59
# @Author : DanYang
# @File : my_log.py
# @Software : PyCharm
# my_logging.py
import logging

logger = logging.getLogger()

logger.setLevel(logging.INFO)

logfile = '../log/log.log'

fh = logging.FileHandler(logfile, encoding='utf-8')
fh.setLevel(logging.INFO)

sh = logging.StreamHandler()
sh.setLevel(logging.INFO)

formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")

fh.setFormatter(formatter)
sh.setFormatter(formatter)

logger.addHandler(fh)
logger.addHandler(sh)

