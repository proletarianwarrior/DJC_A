# -*- coding: utf-8 -*-
# @Time : 2023/11/4 18:33
# @Author : DanYang
# @File : word_cloud.py
# @Software : PyCharm
import sys
from collections import Counter

import pandas as pd
import numpy as np
from PIL import Image
import jieba
from wordcloud import WordCloud
import matplotlib.pyplot as plt

sys.path.append("../config")

from config import STOPWORD_FILE, MY_STOPWORDS
from my_log import logger

df = pd.read_csv("../data/train.csv")


def cut_sentences(text):
    text = [i for i in text if 0x4e00 <= ord(i) <= 0x9fa5]
    text = "".join(text)
    seg_list = jieba.cut(text, cut_all=False)
    word_list = np.array(list(seg_list))
    return word_list


def del_stopwords(data):
    ss = []
    for stopword in STOPWORD_FILE:
        s = np.loadtxt(stopword, encoding="utf-8", dtype=str)
        ss.append(s)
    ss = np.hstack(ss)
    ss = np.unique(ss)

    bollen = np.isin(data, ss)
    data = data[~bollen]
    data = [i for i in data if len(i) > 1]

    return data


def save_words():
    length = len(df["0"])
    for pos, i in enumerate(df["0"]):
        word_list = cut_sentences(i)
        word_list = del_stopwords(word_list)
        df.loc[pos, "cut_words"] = " ".join(word_list)
        print(f"{pos + 1}/{length}")
    df.drop("Unnamed: 0", inplace=True, axis=1)
    df.to_csv("../data/train_words.csv")
    logger.info(f"分词数据train_words.csv保存成功！")


def plot_wordcloud(label):
    df = pd.read_csv("../data/train_words.csv")
    sen_text = df["cut_words"][df["label"] == label]
    sen_text = [str(i) for i in sen_text]
    sen_texts = " ".join(sen_text).split(" ")
    sen_dict = Counter(sen_texts)

    for w in MY_STOPWORDS:
        if w in sen_dict:
            del sen_dict[w]

    mask = np.array(Image.open("../data/mask/enlarged_image.jpg"))
    mask = np.where(mask >= 128, 0, 255)
    wordcloud = WordCloud(font_path="../data/font/STSONG.TTF", background_color="white",
                          max_words=500, width=10000, height=10000, mask=mask, colormap="cividis")
    wordcloud.generate_from_frequencies(sen_dict)

    plt.figure(figsize=(10, 5), dpi=300)
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")
    plt.tight_layout()
    plt.show()

    sort_dict = sorted(list(sen_dict.keys()), key=lambda x: list(sen_dict.values())[list(sen_dict.keys()).index(x)])
    print(sorted(sen_dict.values()))
    print(sort_dict)


if __name__ == '__main__':
    plot_wordcloud(1)
