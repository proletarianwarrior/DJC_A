# -*- coding: utf-8 -*-
# @Time : 2023/11/5 20:19
# @Author : DanYang
# @File : LDA_model.py
# @Software : PyCharm
import pickle

import pandas as pd
from gensim import corpora
from gensim.models import LdaModel
import pyLDAvis.gensim

from my_log import logger


def create_lda_model(num_topics=3):
    df = pd.read_csv("../data/train_words.csv")
    documents = df["cut_words"]
    documents = [str(d) for d in documents]

    tokenized_documents = [document.split(" ") for document in documents]
    dictionary = corpora.Dictionary(tokenized_documents)
    corpus = [dictionary.doc2bow(doc) for doc in tokenized_documents]

    lda_model = LdaModel(corpus, num_topics=num_topics, id2word=dictionary, passes=10)

    lda_model.save("../model/lda_model/LDA_model.lda")
    with open("../model/lda_model/matrix.pkl", "wb") as file:
        pickle.dump({
            "corpus": corpus,
            "dictionary": dictionary
        }, file)


def load_model():
    with open("../model/lda_model/matrix.pkl", "rb") as file:
        matrix_dict = pickle.load(file)
    lda_model = LdaModel.load("../model/lda_model/LDA_model.lda")

    return lda_model, matrix_dict["corpus"], matrix_dict["dictionary"]


def show_topics(num_topics=3, num_words=6):
    lda_model, _, _ = load_model()
    topics = lda_model.show_topics(num_topics=num_topics, num_words=num_words)
    for topic in topics:
        print(topic)
    return topics


def plot_topics():
    """
    绘制主题可视化图像
    :return:
    """
    lda_model, corpus, dictionary = load_model()
    vis_data = pyLDAvis.gensim.prepare(lda_model, corpus, dictionary)
    pyLDAvis.save_html(vis_data, '../data/lda_pass.html')


if __name__ == '__main__':
    show_topics()


