# -*- coding: utf-8 -*-
# @Time : 2023/10/12 23:39
# @Author : DanYang
# @File : config.py
# @Software : PyCharm
import pathlib

# 数据文件路径
SEN_FILE_PATH = pathlib.Path("../data/train_sensitiveness.csv")
INSEN_FILE_PATH = pathlib.Path("../data/train_insensitiveness.csv")
TEST_FILE_PATH = pathlib.Path("../data/test.csv")

# 停用词路径
STOPWORD_FILE = ["baidu_stopwords.txt", "cn_stopwords.txt", "hit_stopwords.txt", "scu_stopwords.txt"]
STOPWORD_FILE = ["../data/stopwords/" + i for i in STOPWORD_FILE]
MY_STOPWORDS = ["中国", "哈哈哈"]
